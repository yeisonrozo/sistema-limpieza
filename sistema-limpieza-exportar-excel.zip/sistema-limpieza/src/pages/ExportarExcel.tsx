import { useState } from "react";
import { supabase } from "../services/supabase";
import "./ExportarExcel.css";

type Row = Record<string, unknown>;
async function obtenerTodasLasFilas(tabla: string): Promise<Row[]> {
  const limite = 1000;
  const acumulado: Row[] = [];
  for (let desde = 0; ; desde += limite) {
    const { data, error } = await supabase.from(tabla).select("*").range(desde, desde + limite - 1);
    if (error) throw new Error(error.message);
    const lote = (data ?? []) as Row[];
    acumulado.push(...lote);
    if (lote.length < limite) return acumulado;
  }
}

const HOJAS = [
  { tabla: "clientes", nombre: "Clientes" },
  { tabla: "facturas", nombre: "Facturas" },
  { tabla: "factura_detalle", nombre: "Detalle facturas" },
  { tabla: "pagos", nombre: "Pagos" },
  { tabla: "minuta_diaria", nombre: "Minutas" },
  { tabla: "servicios", nombre: "Servicios" },
  { tabla: "servicios_cliente", nombre: "Servicios por cliente" },
  { tabla: "configuracion_empresa", nombre: "Empresa" },
  { tabla: "configuracion_facturacion", nombre: "Configuracion facturacion" },
];

function escaparXml(valor: unknown): string {
  if (valor === null || valor === undefined) return "";
  const texto = typeof valor === "object" ? JSON.stringify(valor) : String(valor);
  return texto.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/'/g, "&apos;");
}
function celda(valor: unknown): string {
  const tipo = typeof valor === "number" ? "Number" : "String";
  return `<Cell><Data ss:Type="${tipo}">${escaparXml(valor)}</Data></Cell>`;
}
function hojaXml(nombre: string, filas: Row[]): string {
  const columnas = Array.from(new Set(filas.flatMap(f => Object.keys(f))));
  const encabezado = `<Row>${columnas.map(c => celda(c)).join("")}</Row>`;
  const cuerpo = filas.map(f => `<Row>${columnas.map(c => celda(f[c])).join("")}</Row>`).join("");
  return `<Worksheet ss:Name="${escaparXml(nombre).slice(0,31)}"><Table>${encabezado}${cuerpo}</Table></Worksheet>`;
}
function descargarExcel(hojas: { nombre: string; filas: Row[] }[]) {
  const contenido = `<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">${hojas.map(h => hojaXml(h.nombre, h.filas)).join("")}</Workbook>`;
  const blob = new Blob(["\uFEFF", contenido], { type: "application/vnd.ms-excel;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const enlace = document.createElement("a");
  enlace.href = url;
  enlace.download = `REPORTE_AIM_HIGH_${new Date().toISOString().slice(0,10)}.xls`;
  document.body.appendChild(enlace);
  enlace.click();
  enlace.remove();
  URL.revokeObjectURL(url);
}

export default function ExportarExcel() {
  const [cargando, setCargando] = useState(false);
  const [mensaje, setMensaje] = useState("");
  const [detalle, setDetalle] = useState<string[]>([]);

  const exportar = async () => {
    setCargando(true); setMensaje(""); setDetalle([]);
    try {
      const resultados = await Promise.all(HOJAS.map(async h => {
        try {
          const filas = await obtenerTodasLasFilas(h.tabla);
          return { nombre: h.nombre, filas, error: "" };
        } catch (e) {
          // Algunas instalaciones pueden no tener todas las tablas opcionales.
          return { nombre: h.nombre, filas: [] as Row[], error: `${h.tabla}: ${e instanceof Error ? e.message : "Error de consulta"}` };
        }
      }));

      const errores = resultados.filter(r => r.error).map(r => r.error);
      const hojas: { nombre: string; filas: Row[] }[] = resultados.map(r => ({ nombre: r.nombre, filas: r.filas }));

      const facturas = resultados.find(r => r.nombre === "Facturas")?.filas ?? [];
      const pagos = resultados.find(r => r.nombre === "Pagos")?.filas ?? [];
      const clientes = resultados.find(r => r.nombre === "Clientes")?.filas ?? [];
      const pagosPorFactura = new Map<string, number>();
      pagos.forEach(p => {
        const id = String(p.factura_id ?? "");
        pagosPorFactura.set(id, (pagosPorFactura.get(id) ?? 0) + Number(p.valor ?? 0));
      });
      const nombreCliente = new Map(clientes.map(c => [String(c.id), String(c.nombre ?? "Sin cliente")]));
      const cartera = facturas.map(f => {
        const id = String(f.id ?? "");
        const total = Number(f.total ?? 0);
        const abonado = pagosPorFactura.get(id) ?? 0;
        return {
          numero_factura: f.numero ?? "", fecha: f.fecha ?? "",
          cliente: nombreCliente.get(String(f.cliente_id ?? "")) ?? "Sin cliente",
          total_facturado: total, total_abonado: abonado,
          saldo_pendiente: Math.max(total - abonado, 0), estado: f.estado ?? "",
        };
      }).filter(f => f.saldo_pendiente > 0);
      hojas.push({ nombre: "Cuentas por cobrar", filas: cartera });

      const totalFacturado = facturas.reduce((s, f) => s + Number(f.total ?? 0), 0);
      const totalPagado = pagos.reduce((s, p) => s + Number(p.valor ?? 0), 0);
      const totalCartera = cartera.reduce((s, f) => s + Number(f.saldo_pendiente), 0);
      hojas.unshift({ nombre: "Resumen", filas: [
        { indicador: "Clientes registrados", valor: clientes.length },
        { indicador: "Facturas registradas", valor: facturas.length },
        { indicador: "Total facturado", valor: totalFacturado },
        { indicador: "Total recibido (pagos registrados)", valor: totalPagado },
        { indicador: "Cartera pendiente", valor: totalCartera },
        { indicador: "Facturas con saldo", valor: cartera.length },
        { indicador: "Fecha de exportación", valor: new Date().toLocaleString("en-US") },
      ] });

      descargarExcel(hojas);
      setDetalle(errores);
      setMensaje(errores.length ? "El archivo se descargó, pero algunas tablas no estuvieron disponibles. Revisa los avisos." : "¡Excel generado correctamente! Incluye resumen, cartera y las tablas disponibles.");
    } catch (e) {
      setMensaje(e instanceof Error ? e.message : "No se pudo generar el Excel.");
    } finally { setCargando(false); }
  };

  return <main className="exportar-page">
    <header className="exportar-heading"><span>REPORTES Y RESPALDOS</span><h2>Exportar información</h2><p>Descarga un libro de Excel con los datos administrativos y financieros de Aim High Cleaners LLC.</p></header>
    <section className="exportar-card">
      <div className="exportar-icono">📊</div><h3>Reporte general de la empresa</h3>
      <p>Incluye clientes, facturas, detalle de facturas, pagos, minutas, servicios, configuración y un cálculo de cuentas por cobrar según los abonos registrados.</p>
      <ul><li>Resumen financiero general.</li><li>Deudas por cliente y saldo de cada factura.</li><li>Historial de pagos y servicios realizados.</li><li>Catálogo de servicios y precios por cliente.</li></ul>
      <button onClick={() => void exportar()} disabled={cargando}>{cargando ? "Generando Excel..." : "⬇ Descargar Excel completo"}</button>
      {mensaje && <div className="exportar-mensaje" role="status">{mensaje}</div>}
      {detalle.length > 0 && <details><summary>Tablas no exportadas ({detalle.length})</summary><ul>{detalle.map(e => <li key={e}>{e}</li>)}</ul></details>}
      <small>El archivo se genera en tu navegador con los datos a los que tu usuario tenga permiso de acceso. Guárdalo en una ubicación privada.</small>
    </section>
  </main>;
}
